CH07_AUGraphSpeechSynthesis

This example uses the AUSpeechSynthesis audio unit to speak a string, connected to an AUMatrixReverb unit to provide an "echo" effect.

The program runs as a command-line executable and takes no arguments, meaning you need to either run it from the command line in the Derived Data build directory, or directly from Xcode.

March 13, 2014: This example has been modernized for Xcode 5.1, and has been converted to ARC. There are no code changes compared to what's in the book.