//
//  main.m
//  CH11_MIDIWifiSource
//
//  Created by Chris Adamson on 9/10/11.
//  Copyright 2011 Subsequently and Furthermore, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
	int retVal = UIApplicationMain(argc, argv, nil, nil);
	return retVal;
}
