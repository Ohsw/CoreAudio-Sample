CH09_OpenALOrbitStream

This example uses OpenAL's streaming API to play a song sound that orbits on an ellipse in all three dimensions around the listener; this is heard as a stereo mix on headphones or a typical two-speaker setup.

The program runs as a command-line executable and takes no arguments, meaning you need to either run it from the command line in the Derived Data build directory, or directly from Xcode.

March 13, 2014: This example has been modernized for Xcode 5.1, and has been converted to ARC. There are no code changes compared to what's in the book.